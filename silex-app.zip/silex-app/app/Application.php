<?php

/**
 * Class Application
 */
class Application extends Silex\Application
{
    use \Silex\Application\TwigTrait;

    public function __construct(array $values = array())
    {
        parent::__construct($values);

        $this->bootstrapTwig();

    }

    public function bootstrapTwig()
    {
        $this->register(new \Silex\Provider\TwigServiceProvider(), array(
            'twig.path' => __DIR__ . '/Resources/views'
        ));
    }

}