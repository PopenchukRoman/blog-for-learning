<?php

require_once __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../app/Application.php';

$app = new Application();

# enable debug mode
$app['debug'] = true;

$app->get('/name/{name}', function($name) use($app) {
   return $app->render('hello.html.twig', array(
      'name' => $name
   ));
});

$app->run();